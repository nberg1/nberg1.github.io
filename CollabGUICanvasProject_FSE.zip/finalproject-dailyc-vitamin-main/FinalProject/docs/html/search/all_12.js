var searchData=
[
  ['unaryexpr_1608',['UnaryExpr',['../class_catch_1_1_unary_expr.html',1,'Catch::UnaryExpr&lt; LhsT &gt;'],['../class_catch_1_1_unary_expr.html#ae02f666a1e64da728628aa2033e1d6e7',1,'Catch::UnaryExpr::UnaryExpr()']]],
  ['undo_1609',['undo',['../structnk__text__edit.html#aafeb06f0915d80cd8e4b16e9c3f3ef03',1,'nk_text_edit::undo()'],['../class_app.html#a6cdf0b6d448f4bfef81e210049ec82d6',1,'App::undo()'],['../class_command.html#aa89348c98fd2194f1617d70f57a3ae6c',1,'Command::undo()'],['../class_draw.html#adb1037c5994317dc7f0ada3a89bc10eb',1,'Draw::undo()']]],
  ['undo_5fchar_1610',['undo_char',['../structnk__text__undo__state.html#a1e9a3b0a6cb7a1e2aee05c2de2ab618d',1,'nk_text_undo_state']]],
  ['undo_5fchar_5fpoint_1611',['undo_char_point',['../structnk__text__undo__state.html#a2c98283f50f5ef3da53acee6b0b4f85d',1,'nk_text_undo_state']]],
  ['undo_5fpoint_1612',['undo_point',['../structnk__text__undo__state.html#acad719143b81dc7d2463c1d06f03c672',1,'nk_text_undo_state']]],
  ['undo_5frec_1613',['undo_rec',['../structnk__text__undo__state.html#ad8d4523c523f3f1a90fcc709f4db8756',1,'nk_text_undo_state']]],
  ['ungrab_1614',['ungrab',['../structnk__mouse.html#a3420ca85bb04a09dd14694dfb394c7f0',1,'nk_mouse']]],
  ['unknown_1615',['Unknown',['../struct_catch_1_1_result_was.html#a624e1ee3661fcf6094ceef1f654601efa65721dda02fe5efb522e7449e496608a',1,'Catch::ResultWas']]],
  ['unprintablestring_1616',['unprintableString',['../namespace_catch_1_1_detail.html#a466775f4eec29ffef29ab334cd885136',1,'Catch::Detail']]],
  ['unsetexceptionguard_1617',['unsetExceptionGuard',['../class_catch_1_1_assertion_handler.html#a5638dc6be96257de59b111b6c3dc49f1',1,'Catch::AssertionHandler']]],
  ['update_1618',['update',['../main_8cpp.html#a2dc74403417e5cca232a55ea353748d2',1,'main.cpp']]],
  ['updatecallback_1619',['UpdateCallback',['../class_app.html#ac3904b1ebd0f21abbacd7e4fb632b177',1,'App']]],
  ['use_5fclipping_1620',['use_clipping',['../structnk__command__buffer.html#a65f789788b8a857efa0c4080781591f7',1,'nk_command_buffer']]],
  ['use_5fpool_1621',['use_pool',['../structnk__context.html#a10afb1419df73de41b2be1d0bff8523c',1,'nk_context']]],
  ['useactiveexception_1622',['useActiveException',['../class_catch_1_1_assertion_handler.html#ae5c135c28109bf82efeefeb00c0ddb22',1,'Catch::AssertionHandler']]],
  ['userdata_1623',['userdata',['../structnk__allocator.html#a15aa4d412b676a8578ed07f73eac6455',1,'nk_allocator::userdata()'],['../structnk__user__font.html#a227c31a1ef360c78c98678d8d8546c03',1,'nk_user_font::userdata()'],['../structnk__clipboard.html#a40e1bfd251716852fe3fa3f6856aeb2c',1,'nk_clipboard::userdata()'],['../structnk__command__buffer.html#adc12ff0f2c3965f2df8da6d83c5b9903',1,'nk_command_buffer::userdata()'],['../structnk__style__button.html#a486c8383bd02dae018cacaa370bf0c43',1,'nk_style_button::userdata()'],['../structnk__style__toggle.html#ac3df28dd0fd8945d9d4effbd0953c957',1,'nk_style_toggle::userdata()'],['../structnk__style__selectable.html#ab0cdeefe700feb442aefb82a49aa930b',1,'nk_style_selectable::userdata()'],['../structnk__style__slider.html#a6376ac01b14a9da29af611b9d2aeecd2',1,'nk_style_slider::userdata()'],['../structnk__style__progress.html#af990f8b225eba54c3ad6b0137e619584',1,'nk_style_progress::userdata()'],['../structnk__style__scrollbar.html#a9ffd74fad1ee2f9b293693ebd77f1110',1,'nk_style_scrollbar::userdata()'],['../structnk__style__property.html#a453d9d4df7e05c98746e5fae61725a2f',1,'nk_style_property::userdata()']]],
  ['uv_1624',['uv',['../structnk__draw__null__texture.html#ae00f89beb79ed9aa53d2ddcbdd1ea7c7',1,'nk_draw_null_texture']]]
];
