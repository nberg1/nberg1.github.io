var searchData=
[
  ['pluralise_1799',['pluralise',['../struct_catch_1_1pluralise.html',1,'Catch']]]
];
