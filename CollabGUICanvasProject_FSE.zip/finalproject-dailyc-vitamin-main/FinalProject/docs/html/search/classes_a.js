var searchData=
[
  ['registrarfortagaliases_1800',['RegistrarForTagAliases',['../struct_catch_1_1_registrar_for_tag_aliases.html',1,'Catch']]],
  ['resultdisposition_1801',['ResultDisposition',['../struct_catch_1_1_result_disposition.html',1,'Catch']]],
  ['resultwas_1802',['ResultWas',['../struct_catch_1_1_result_was.html',1,'Catch']]]
];
