var searchData=
[
  ['large_3302',['LARGE',['../_app_8cpp.html#ac27c2124ca2aed651e06aba3a1468ecb',1,'LARGE():&#160;App.cpp'],['../main_8cpp.html#ac27c2124ca2aed651e06aba3a1468ecb',1,'LARGE():&#160;main.cpp']]]
];
