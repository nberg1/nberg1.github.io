var searchData=
[
  ['oftype_2962',['OfType',['../struct_catch_1_1_result_was.html#a624e1ee3661fcf6094ceef1f654601ef',1,'Catch::ResultWas']]]
];
