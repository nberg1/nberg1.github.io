var searchData=
[
  ['pluralise_2451',['pluralise',['../struct_catch_1_1pluralise.html#a5c55e22de2416cfe416edf715c6b9234',1,'Catch::pluralise']]],
  ['popscopedmessage_2452',['popScopedMessage',['../struct_catch_1_1_i_result_capture.html#a42bcb13276706bf8c3ce081ce16d37fd',1,'Catch::IResultCapture']]],
  ['pushscopedmessage_2453',['pushScopedMessage',['../struct_catch_1_1_i_result_capture.html#a91d154c1e087e383dcde5aad95cb6a05',1,'Catch::IResultCapture']]]
];
