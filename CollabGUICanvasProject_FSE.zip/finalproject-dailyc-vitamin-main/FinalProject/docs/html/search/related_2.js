var searchData=
[
  ['settags_3235',['setTags',['../struct_catch_1_1_test_case_info.html#a0fe44abaf18ae7c26f98a9fc2b08679c',1,'Catch::TestCaseInfo']]],
  ['stringreftestaccess_3236',['StringRefTestAccess',['../class_catch_1_1_string_ref.html#a420e64e1652de1b0d427775781b018f5',1,'Catch::StringRef']]]
];
