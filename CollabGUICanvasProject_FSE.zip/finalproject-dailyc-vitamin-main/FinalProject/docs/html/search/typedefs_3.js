var searchData=
[
  ['stringmatcher_2920',['StringMatcher',['../namespace_catch.html#aba438977e831821a2eeca82b9b4f4af2',1,'Catch']]]
];
