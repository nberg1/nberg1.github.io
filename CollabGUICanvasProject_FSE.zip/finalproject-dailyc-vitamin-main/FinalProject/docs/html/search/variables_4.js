var searchData=
[
  ['edit_2631',['edit',['../structnk__style__property.html#a535d43c8849cb49b3ec2fcd959512c60',1,'nk_style_property::edit()'],['../structnk__style.html#a2e6872e44b048d5e562994b0f9acc4eb',1,'nk_style::edit()'],['../structnk__window.html#a5ff816faab95d10bf9bdff4518c268ea',1,'nk_window::edit()']]],
  ['end_2632',['end',['../structnk__list__view.html#a5f53b59714337769b991392a24ef64f7',1,'nk_list_view::end()'],['../structnk__command__line.html#abae974f2c6c475c9cdd5d19e8c5a3ba1',1,'nk_command_line::end()'],['../structnk__command__curve.html#aa69e2aea76ec8cadbf55fd27557d6582',1,'nk_command_curve::end()'],['../structnk__command__buffer.html#a12fd620faceb994143967021e44a8b71',1,'nk_command_buffer::end()'],['../structnk__popup__buffer.html#a630c901d09e64b5945e5a9c760153496',1,'nk_popup_buffer::end()'],['../structnk__context.html#a70f3687079206d314b2006db5fc3da05',1,'nk_context::end()']]]
];
