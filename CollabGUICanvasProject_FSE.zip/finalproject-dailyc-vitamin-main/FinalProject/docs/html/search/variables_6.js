var searchData=
[
  ['g_2647',['g',['../structnk__color.html#a5f9b6e27eec7cc99ab12fa52a31ca6d1',1,'nk_color::g()'],['../structnk__colorf.html#a41ff42d9dce5f1812132b305cf3395fb',1,'nk_colorf::g()']]],
  ['global_5falpha_2648',['global_alpha',['../structnk__convert__config.html#ad344c555b0c1ce0a07dded48860ceb00',1,'nk_convert_config']]],
  ['grab_2649',['grab',['../structnk__mouse.html#a93b114f1d129ce336d0d237980337ac9',1,'nk_mouse']]],
  ['grabbed_2650',['grabbed',['../structnk__mouse.html#a498f60d6bf88ca50aacbddcb2a2032ad',1,'nk_mouse']]],
  ['group_5fborder_2651',['group_border',['../structnk__style__window.html#a01f2264c6f00fbfb81418c14bcccdb84',1,'nk_style_window']]],
  ['group_5fborder_5fcolor_2652',['group_border_color',['../structnk__style__window.html#a3f27932c225305d78887c18aeb788c37',1,'nk_style_window']]],
  ['group_5fpadding_2653',['group_padding',['../structnk__style__window.html#a86d3a9f2f90380097f15b5abf09b0254',1,'nk_style_window']]],
  ['grow_5ffactor_2654',['grow_factor',['../structnk__buffer.html#ab4ec59165f6aa6e9358bced8070cc84e',1,'nk_buffer']]],
  ['gui_5fwindow_2655',['gui_window',['../class_app.html#a3512de682ab5fccad9a03e973ee8efd9',1,'App']]]
];
