var searchData=
[
  ['id_2666',['id',['../unionnk__handle.html#ab4db605f712876c795e39598b25ca9b3',1,'nk_handle']]],
  ['image_2667',['image',['../unionnk__style__item__data.html#ae0256c98c4e25f3b8ad0596d6dd68407',1,'nk_style_item_data']]],
  ['image_5fpadding_2668',['image_padding',['../structnk__style__button.html#ab53cdca97ddb24dea561e1cec88b3ba2',1,'nk_style_button::image_padding()'],['../structnk__style__selectable.html#a6a88ded1389d9a57728e885d9cfae6e5',1,'nk_style_selectable::image_padding()']]],
  ['img_2669',['img',['../structnk__cursor.html#ae85598fd872f474a4e63e92bbee10a92',1,'nk_cursor::img()'],['../structnk__command__image.html#ac95060c32a20e739a464fb40234282fa',1,'nk_command_image::img()']]],
  ['inc_5fbutton_2670',['inc_button',['../structnk__style__slider.html#a7d7bce402c16ed819a64c72b5ee1928f',1,'nk_style_slider::inc_button()'],['../structnk__style__scrollbar.html#a3184981c83202a1633f77a6fa224ff98',1,'nk_style_scrollbar::inc_button()'],['../structnk__style__property.html#aee8c9b461e7959b29108e1510d95cc09',1,'nk_style_property::inc_button()']]],
  ['inc_5fsymbol_2671',['inc_symbol',['../structnk__style__slider.html#a82d0f1a7c09ae08a0462047b1c4d035d',1,'nk_style_slider::inc_symbol()'],['../structnk__style__scrollbar.html#ae880b936bb999860f48aeb9ab52e6a93',1,'nk_style_scrollbar::inc_symbol()']]],
  ['indent_2672',['indent',['../structnk__style__tab.html#a535cb708f61a9cba5ee581ab044b8f71',1,'nk_style_tab']]],
  ['index_2673',['index',['../structnk__chart__slot.html#ae66e71dddf3f3811ebfd06a21c49157e',1,'nk_chart_slot::index()'],['../structnk__row__layout.html#a2f67dbabb90fc669f89d146b72096214',1,'nk_row_layout::index()']]],
  ['initialized_2674',['initialized',['../structnk__text__edit.html#a59ae91abb42caf733b9a3af950f9f288',1,'nk_text_edit']]],
  ['input_2675',['input',['../structnk__context.html#abee1c200e8e185fe718556c0ddff31ad',1,'nk_context']]],
  ['insert_5flength_2676',['insert_length',['../structnk__text__undo__record.html#ae7f5973ad63b09bf0be082779de9b61e',1,'nk_text_undo_record']]],
  ['item_2677',['item',['../structnk__row__layout.html#a9cf7d946ac238a1d740b30274c94d0c6',1,'nk_row_layout']]],
  ['item_5fheight_2678',['item_height',['../structnk__row__layout.html#a6b49798d8a6212635e6ff43ff18ff1b3',1,'nk_row_layout']]],
  ['item_5foffset_2679',['item_offset',['../structnk__row__layout.html#aed3b80106355700ff3c6f2b48955417a',1,'nk_row_layout']]],
  ['item_5fwidth_2680',['item_width',['../structnk__row__layout.html#a9bed03da7c7e09d8acbcd40ea868a1a0',1,'nk_row_layout']]]
];
