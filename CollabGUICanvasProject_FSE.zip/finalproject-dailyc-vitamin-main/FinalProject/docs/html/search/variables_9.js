var searchData=
[
  ['keyboard_2681',['keyboard',['../structnk__input.html#a07db4d8c752d4e9fcc7e18638dfa8740',1,'nk_input']]],
  ['keys_2682',['keys',['../structnk__keyboard.html#a7f4bc6e6c826efeef5ac3ccfe7be2951',1,'nk_keyboard::keys()'],['../structnk__table.html#abe02ed8fb83c928c36e8e719d64e2cbf',1,'nk_table::keys()']]]
];
