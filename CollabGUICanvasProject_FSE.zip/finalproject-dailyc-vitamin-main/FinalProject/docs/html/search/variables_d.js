var searchData=
[
  ['offset_2743',['offset',['../structnk__cursor.html#ae01b7938eb679481a8ef549c27a59080',1,'nk_cursor::offset()'],['../structnk__buffer__marker.html#a225c3628eb1e93f2400496110c4bd87a',1,'nk_buffer_marker::offset()'],['../structnk__menu__state.html#a5c9dbc6f4874d334884970a3a50a9106',1,'nk_menu_state::offset()']]],
  ['offset_5fx_2744',['offset_x',['../structnk__panel.html#a2aced4e49f290e87ed6c2823122d946c',1,'nk_panel']]],
  ['offset_5fy_2745',['offset_y',['../structnk__panel.html#a6704d6eb0414bdeaf9cba1facdb4c729',1,'nk_panel']]],
  ['old_2746',['old',['../structnk__edit__state.html#ab71fb9bbac77248af5f1c3bd1471ddfc',1,'nk_edit_state::old()'],['../structnk__property__state.html#a425994ca840cd84b4bb43c14cc761f19',1,'nk_property_state::old()']]],
  ['op_2747',['op',['../class_app.html#a0e0cdadbcb123ddb8ba633fd062b8666',1,'App']]],
  ['option_2748',['option',['../structnk__style.html#a12e31b1eff50ff00fc327325ce6cd7f9',1,'nk_style']]],
  ['overlay_2749',['overlay',['../structnk__context.html#ae51cac633c54b94a63c8fe77b9558f4a',1,'nk_context']]]
];
