Project 4 README - Team BurBers
Joseph Burns
Nicole Berg

For this project, we developed our program incrementally, as any viable results confirming whether
or not we developed a good implementation was largely dependent on other aspects of the program
working correctly. Before receiving any data from the server, we first needed to craft a good
SYN packet, which required building a packet with correct IP and TCP headers. This required
developing a good checksum algorithm as well as properly building the TCP and IP headers
such that each element in the headers were correct and were represented in the right number of
bytes (source IP, dest IP, IP protocol, etc for IP - source port, dest port, flags, etc for TCP).

Once we were able to send a good packet and receive one in return, we turned our attention to reading 
incoming packets. This was slightly easier with a working knowledge of how to craft packets, 
though parsing bytes certainly had its own challenges, such as converting bytes to hex and then 
using hex to generate checksums and integer values that could be compared, as well as verifying 
information and discarding either corrupted packets or packets not destined for our program. 
With the ability to send and receive packets nailed down, the handshake and teardown methods came fairly quickly.

Implementing the request packets required increasing the congestion window as well as checking acks from
the server. Finding a way to consistently increase congestion window size while also building in
method for reducing the cwnd if duplicate acks were received or if acks for a particular packet
were not received at all was tricky, but ended up working without too many hiccups. Receiving
the response was quite difficult, largely stemming from the native Linux settings on Ubuntu.
Linux has a nasty habit of merging packets before delivering them to sockets by default, a problem
Professor Choffnes aided in correcting. By turning certain offloading features off, we were able
to get the packets as they were sent from the server, and all was well; checksums were checked, payloads
were received, and IP and TCP headers were sufficiently verified. Developing a method of
placing the packets in order as well as not storing duplicate packets was fairly difficult, mostly
due to optimization troubles. Without sufficiently searching packets that had already been received
to ensure duplicates were not being produced as well as ensuring there were no missing packets from the
data, the program slowed to a crawl, and thus we took several optimization measures to speed these checks
up.

Downloading the file was the easiest part - if the data could be decoded using utf-8, we decoded
the data and stored it, otherwise we treated the data as a binary file and stored it in the bytes
as received.

For the distribution of labor, Joe identified and created the correct TCP and IP headers that were to be 
included in the packets. Once the headers were built out, Joe further compiled the packets to include all 
the appropriate data required. He was able to set up the initial handshake between server and client and 
start the transmission to be able to receive packets with the requested data. Once all packets were received, 
Joe constructed the teardown of the connection. Joe brilliantly handled the checksum calculations for all packets
and managed to filter out packets that were not part of our program.

Nicole handled the HTTP headers and compiling the GET request once the initial handshake was accomplished. Nicole 
was also in charge of documentation of the code to ensure good readability and clarity of the computations 
and design decisions included. She also assisted in setting up the initial connection between server and client 
to ensure the client received packets on the receiving raw socket. Nicole also ensured that the random ports 
chosen on the host machine were not open and already being used by the machine before connecting and utilizing 
them for transmission.
