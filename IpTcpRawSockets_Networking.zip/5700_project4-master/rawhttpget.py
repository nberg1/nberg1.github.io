#!/usr/bin/env python3

import socket
from subprocess import check_output
from struct import *
import binascii
import random
import time
import sys

#### COME AS YOU ARE COMMAND ->> sudo ethtool -K ens33 gro off

# last ack num to be carried through methods
ACK_NUM = 0
# seq num to be carried through methods
SEQ_NUM = 0
# congestion window size
CWND = 1
# max size of packet that can be received
RECV_SIZE = 5000

def getChecksum(data):
    '''
    Gets the Checksum
    :param data: packet
    :return: returns the calculated checksum
    '''

    # counter for checksum
    _sum = 0
    # get the length of the data
    count = len(data)

    # use as index value
    index = 0
    # check 16 bits at a time
    while index < count:
        # shift first 8 bits to left and add to second 8 bits
        # print(str(data[index:index+4]))
        if data[index + 2: index + 4] == '':
            _sum += (int(data[index:index + 2], 16) << 8)
        else:
            _sum += (int(data[index:index + 2], 16) << 8) + (int(data[index + 2: index + 4], 16))
            # increment index by 4
        index += 4

    # if the sum of bits is greater than a 16 bit unsigned int, strip vals greater than
    # 2^16, and add original 16 to stripped vals
    while _sum > pow(2, 16) - 1:
        stripped = (_sum >> 16)
        first_16 = _sum & 0xffff
        _sum = stripped + first_16

    # find ones complement for found sum
    return ~_sum & 0xffff


def makePacket(host_ip, destination_ip, source_port, dest_port, seq, ack, types: list, message):
    '''
    Makes the packet, include IP header ad TCP header
    :param host_ip: host ip string
    :param destination_ip: destination ip string
    :param source_port: source port string
    :param dest_port: destination port string
    :param seq: sequence number int
    :param ack: ack number int
    :param types: list
    :param message: string message of the data sending in packet
    :return: return compiled packet
    '''

    # line 4
    tcp_header_len = 5  # data offset                   4 bits H for unsigned int merge \/ \/

    # adding MSS to limit size of packets sent
    if 'SYN' in types:
        tcp_header_len = 6

    res_flags = 0  # for later use                 6 bits H for unsigned int merge /\ \/
    # NOTE THIS IS WHERE WE DO SYN/FIN sin = 000010, fin = 000001
    control_bits = 0  # indicates type of bit         6 bits H for unsigned int merge /\ /\
    for _type in types:
        if _type == "FIN":
            control_bits = control_bits + 1
        elif _type == "SYN":
            control_bits = control_bits + (1 << 1)
        elif _type == "RST":
            control_bits = control_bits + (1 << 2)
        elif _type == "PSH":
            control_bits = control_bits + (1 << 3)
        elif _type == "ACK":
            control_bits = control_bits + (1 << 4)
        elif _type == "URG":
            control_bits = control_bits + (1 << 5)

    # number of octets we can receive (calling 1000 as default)
    window = 64240  # size of our advertised window 16 bits H for unsigned int

    # line 5
    tcp_checksum = 0  # tcp checksum - calc later     16 bits H for unsigned int
    urgent_ptr = 0  # only set with URG cntrl bit   16 bits H for unsigned int

    # merge offset, reserved, and control bits into single unsigned int
    do_res_cntrl_bits = (tcp_header_len << 12) + (res_flags << 6) + control_bits

    # make IP packet header in the following order:
    # first line
    ip_version = 4  # ip version is 4               4 bits  B unsigned int merge \/
    ip_header_len = 5  # ip header length is 5 (20 bytes)   4 bits  B unsigned int merge /\
    type_of_service = 0  # 0 means 'routine' service     8 bits  B for unsigned int (1 byte)
    datagram_len = (ip_header_len + tcp_header_len) * 4 + len(message.encode('utf-8')) # length of packet to be calculated       16 bits H for unsigned short (2 bytes)

    # second line
    packet_id = 0  # identifies packet fragment    16 bits H for unsigned short
    flags = (1 << 1)  # flags, to be maniped in trans 3  bits H for unsigned short merge \/
    fragment_offset = 0  # offset of datagram            13 bits H for unsigned short merge /\

    # third line
    ttl = 255  # time to live                  8 bits B for unsigned int
    protocol = 6  # assigned protocol number(TCP) 8 bits B for unsigned int
    checksum = 0  # checsum to be calculated      16 bits H for unsigned short

    # fourth line - source address, 32 bits, I for unsigned int
    source_ip = socket.inet_aton(host_ip)

    # fifth line - destination address, 32 bits, I for unsigned int
    dest_ip = socket.inet_aton(destination_ip)

    # merge ip version and ihl into one byte
    ip_ihl = (ip_version << 4) + ip_header_len
    # merge flags and fragment offset into one byte
    flag_frag_offset = (flags << 13) + fragment_offset

    # calculate IP checksum
    ip_checksum_vals = pack("!BBHHHBB", ip_ihl, type_of_service, datagram_len * 4, packet_id,
                            flag_frag_offset, ttl, protocol) + source_ip + dest_ip
    ip_vals = str(binascii.hexlify(ip_checksum_vals))
    ip_vals = ip_vals[2:-1]
    ip_checksum = getChecksum(ip_vals)

    # build IP header
    ip_header = pack("!BBHHHBBH", ip_ihl, type_of_service, datagram_len, packet_id,
                     flag_frag_offset, ttl, protocol, ip_checksum) + source_ip + dest_ip

    # create tcp header with 0 checksum
    tcp_header = pack('!HHIIHHHH', source_port, dest_port, seq, ack, do_res_cntrl_bits, window,
                      tcp_checksum, urgent_ptr)

    if "SYN" in types:
        mss = pack("!BBH", 2, 4, 1460)
        tcp_header += mss

    # create psuedo IP header
    psh = source_ip + dest_ip + pack('!HH', protocol, tcp_header_len * 4 + len(message))

    # create temp packet for tcp checksum
    psh = psh + tcp_header + str.encode(message)

    # convert psh bytes into hex, and get checksum
    val = str(binascii.hexlify(psh))

    val = val[2:-1]
    tcp_checksum = getChecksum(val)

    # create tcp header with checksum
    tcp_header = pack('!HHIIHHHH', source_port, dest_port, seq, ack, do_res_cntrl_bits, window,
                      tcp_checksum, urgent_ptr)

    if "SYN" in types:
        mss = pack("!BBH", 2, 4, 1460)
        tcp_header += mss

    # final full packet
    packet = ip_header + tcp_header + str.encode(message)

    return packet


def readPacket(data, destination_ip, port):
    '''
    reads the packet received
    :param data: packet received
    :param destination_ip: destionation ip string of where packet received from
    :param port: port receiving on
    :return:
    '''
    # get data from entire packet and check checksum val
    hexed_data = binascii.hexlify(data)
    # print(data)
    # print(hexed_data)

    # -----IP CHECKS------ #

    # get length of ip header
    ip_header_len = hexed_data[1] & 0xf
    ip_header_len_chars = ip_header_len * 8

    ip_header_ints = []
    index = 0
    while index < ip_header_len_chars:
        ip_header_ints.append(int(hexed_data[index: index + 2], 16))
        index += 2

    # check remote IP address
    remote_ip = '.'.join(str(x) for x in ip_header_ints[12:16])
    if remote_ip != destination_ip:
        raise ValueError('WRONG_PACKET')

    # And now for something completely different
    # (tcp port check)

    # get length of tcp header
    tcp_header_len_index = ip_header_len_chars + 24
    tcp_header_len = (int(hexed_data[tcp_header_len_index:tcp_header_len_index + 2], 16) >> 4) & 0xf
    tcp_header_len_chars = tcp_header_len * 8

    # get data from TCP header in packet and check checksum val
    tcp_header_ints = []
    while index < ip_header_len_chars + tcp_header_len_chars:
        tcp_header_ints.append(int(hexed_data[index: index + 2], 16))
        index += 2

    # if not the right port, mark as wrong packet
    given_port = (tcp_header_ints[2] << 8) + tcp_header_ints[3]
    if given_port != port:
        raise ValueError("WRONG_PACKET")

    # Back to IP checks

    # check protocol - should be 6 for TCP
    if ip_header_ints[9] != 6:
        raise ValueError('BAD_PACKET')

    # check ip header checksum - if not right type of packet, will be bad, if corrupted, will be bad
    ip_checksum_data = hexed_data[:20] + hexed_data[24:ip_header_len_chars]
    ip_checksum = getChecksum(ip_checksum_data)
    if ip_checksum != int(hexed_data[20:24], 16):
        raise ValueError('BAD_PACKET')

    # -----TCP CHECKS----- #
    # NOTE tcp header ints are gathered earlier to check port such that BAD PACKET is never thrown before
    # WRONG PACKET

    # get message in original bytes to inform length in psuedo-ip header
    message = binascii.unhexlify(hexed_data[ip_header_len_chars + tcp_header_len_chars:])

    # get data from IP and TCP header in packet and check TCP checksum val
    # make IP psuedo header
    src_ip = (ip_header_ints[12] << 24) + (ip_header_ints[13] << 16) \
             + (ip_header_ints[14] << 8) + ip_header_ints[15]
    dst_ip = (ip_header_ints[16] << 24) + (ip_header_ints[17] << 16) \
             + (ip_header_ints[18] << 8) + ip_header_ints[19]
    psh = pack('!IIHH', src_ip, dst_ip, ip_header_ints[9], tcp_header_len * 4 + len(message))

    # gather info for TCP header w/ 0 checksum and additional data
    tcp_checksum_data = b''.join([hexed_data[ip_header_len_chars: ip_header_len_chars + 32],
                                 hexed_data[ip_header_len_chars + 36: ip_header_len_chars + tcp_header_len_chars]])

    _psh = binascii.hexlify(psh) + tcp_checksum_data + hexed_data[ip_header_len_chars + tcp_header_len_chars:]
    tcp_checksum_str = str(_psh)
    # join psuedo IP and TCP header and get checksum
    tcp_checksum_str = tcp_checksum_str[2:-1]
    tcp_checksum = getChecksum(tcp_checksum_str)
    # check calculated checksum against tcp checksum
    if tcp_checksum != int(hexed_data[ip_header_len_chars + 32: ip_header_len_chars + 36], 16):
        raise ValueError('BAD_PACKET')


    # get flags
    types = []
    flags = tcp_header_ints[13]
    if flags & 1 == 1:
        types.append("FIN")
    if (flags >> 1) & 1 == 1:
        types.append("SYN")
    if (flags >> 4) & 1 == 1:
        types.append("ACK")

    # get next acknowledgement number -- will be seq number in next packet
    ack_num = (tcp_header_ints[8] << 24) + (tcp_header_ints[9] << 16) \
              + (tcp_header_ints[10] << 8) + tcp_header_ints[11]

    # get next sequence number -- will be ack num + 1 in next packet
    seq_num = (tcp_header_ints[4] << 24) + (tcp_header_ints[5] << 16) \
              + (tcp_header_ints[6] << 8) + tcp_header_ints[7]

    # get the size of the tcp payload
    tcp_payload = len(message)

    return ack_num, seq_num, types, tcp_payload, message


def handshake(send_sock, recv_sock, machine_host, destination_ip, port):
    '''
    Create the initial connection ("handshake") between client and server
    :param send_sock: raw socket sending the packet on
    :param recv_sock: raw socket receiving the packet on
    :param machine_host: string machine host ip
    :param destination_ip: string destination ip address
    :param port: port int
    :return:
    '''
    global ACK_NUM
    global SEQ_NUM
    global LAST_ACKED

    # set persistent shutdown value - if in excess of 3 minutes, terminate connection entirely
    shutdown_timeout_val = int(time.time())
    # set timeout val -- if no packet from server is detected (good or bad), resend after 60 seconds
    timeout_val = int(time.time())
    # Create SYN Packet
    while True:
        # Send FIN/ACK to initiate teardown
        syn_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, SEQ_NUM, ["SYN"], '')
        send_sock.sendto(syn_packet, (destination_ip, 0))

        # set socket to timeout if there are no packets whatsoever coming into the machine
        recv_sock.settimeout(60)
        try:
            # resend flag determines whether or not the packet needs to be resent
            resend = False
            # continue waiting for SYN/ACK packet - sfit through other packets in meantime
            # break upon finding SYN/ACK
            while True:
                # if no response in 180 seconds, raise connection error, shut down program
                if int(time.time()) - shutdown_timeout_val >= 180:
                    raise ConnectionError("Error connecting to server - aborting")
                # if 60 seconds since response from server, resend initial syn packet
                elif int(time.time()) - timeout_val >= 60:
                    resend = True
                    break

                try:
                    # Receive SYN/ACK
                    data = recv_sock.recv(RECV_SIZE)
                    ack_num, seq_num, types, tcp_payload, message = readPacket(data, destination_ip, port)
                    # if SYN and ACK is in packet, good connection, send ack back
                    if "SYN" in types and "ACK" in types:
                        break
                except ValueError as e:
                    # if value error is bad packet, is response from server, just has corrupted values,
                    # resend last packet to retry good reception, reset timeout vals
                    if str(e) == 'BAD_PACKET':
                        timeout_val = int(time.time())
                        shutdown_timeout_val = int(time.time())
                        resend = True
                    # otherwise, is not for this program, continue searching for good packets
                    continue
            # if resend value is not set to true, break loop, continue with connection
            if not resend:
                break
        # if there is a socket timeout (60 seconds), resend init syn packet
        except socket.timeout:
            continue

    # get initial ack num and seq num -- will be checked in all other connections for missing segments
    # increase seq_num by 1 to complete handshake
    ACK_NUM = ack_num
    SEQ_NUM = seq_num + 1

    # Send ACK
    ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, SEQ_NUM, ["ACK"], "")
    send_sock.sendto(ack_packet, (destination_ip, 0))


def teardown(send_sock, recv_sock, machine_host, destination_ip, port):
    '''
    Tears down the connection between client and server
    :param send_sock: socket sending packet on
    :param recv_sock: socket receiving response on
    :param machine_host: string machine host ip
    :param destination_ip: string destination ip address
    :param port:
    :return:
    '''
    global ACK_NUM
    global SEQ_NUM

    # set shutdown val - if not packet from server is detected after 180 seconds, sever connection
    shutdown_timeout_val = int(time.time())
    # set timeout val -- if no packet from server is detected (good or bad), resend after 60 seconds
    timeout_val = int(time.time())

    while True:
        # Send FIN/ACK to respond to teardown
        ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, SEQ_NUM, ["FIN", "ACK"], "")
        send_sock.sendto(ack_packet, (destination_ip, 0))

        recv_sock.settimeout(60)
        try:
            # resend flag determines whether or not the packet needs to be resent
            resend = False

            while True:
                # if no response in 180 seconds, raise connection error, shut down program
                if int(time.time()) - shutdown_timeout_val >= 180:
                    raise ConnectionError("Error connecting to server - aborting")
                # if 60 seconds since response from server, resend initial syn packet
                elif int(time.time()) - timeout_val >= 60:
                    resend = True
                    break
                try:
                    # Receive ACK indicating connection FIN received
                    data = recv_sock.recv(RECV_SIZE)
                    ack_num, seq_num, types, tcp_payload, message = readPacket(data, destination_ip, port)
                    # add check for ACK here
                    if 'ACK' in types and tcp_payload == 0:
                        # if ack num and seq num are not what was expected, received out of order byte, resend FIN/ACK
                        break
                except ValueError as e:
                    # if value error is bad packet, is response from server, just has corrupted values,
                    # resend last packet to retry good reception, reset timeout vals
                    if str(e) == 'BAD_PACKET':
                        timeout_val = int(time.time())
                        shutdown_timeout_val = int(time.time())
                        resend = True
                    # otherwise, is not for this program, continue searching for good packets
                    else:
                        continue

            if not resend:
                break
        except socket.timeout:
            continue


# handle sending as many packets as is allowed by congestion window
# STILL HAVE TO IMPLMENT RETRANSMISSION TIMEOUT AND 3 MINUTE TIMEOUT
def sendRequest(send_sock, recv_sock, machine_host, destination_ip, port, message):
    '''
    send the Request
    :param send_sock: raw socekt sending packet on
    :param recv_sock: raw socket receiving response on
    :param machine_host: string machine host ip address
    :param destination_ip: string destination ip address
    :param port: int port num
    :param message: string data/message to send in packet
    :return:
    '''
    global ACK_NUM
    global SEQ_NUM
    global CWND

    # track parents_sent and data left in message - message sent in any packet
    # should not except 1460 bytes (RECV_SIZE byte total -- need way to break this up)
    message_index = 0

    # cut up message here to show cwnd increase
    messages = []
    # breaks up message to show cwnd increase with good acks
    for i in range(0, len(message), 4):
        if i + 4 < len(message):
            messages.append(message[i:i+4])
        else:
            messages.append(message[i:])

    # set time to shut down connection completely
    shutdown_timeout_val = int(time.time())
    # RECEIVE ACKS FROM REQUEST
    timeout_val = int(time.time())

    # contains all packets sent to receiver
    sent_packets = []
    # counts number of duplicate acks
    duplicate_acks = 0

    # IMPLEMENT CONGESTION WINDOW INCREASE
    # continue sending messages until whole message has been sent
    while message_index < len(messages):
        # SEND PACKETS IN THE REQUEST

        packets_sent = 0
        curr_ack = ACK_NUM
        confirmed_index = message_index
        # continue sending packets until CWND is reached OR all messages have been sent
        # set to logical 'and' so while loop exits depending on which exit condition is met first
        while packets_sent < CWND and message_index < len(messages):
            # send messages and increment ack num by the length of the tcp payload
            next_ack = curr_ack + len(messages[message_index])
            # keep track of acks sent -- if any acks are missing, retransmit from that ack
            sent_packets.append([curr_ack, next_ack, message_index, False])
            message_packet = makePacket(machine_host, destination_ip, port, 80, curr_ack, SEQ_NUM, ["ACK", "PSH"],
                                        messages[message_index])
            send_sock.sendto(message_packet, (destination_ip, 0))
            curr_ack = next_ack
            packets_sent += 1
            message_index += 1

        while confirmed_index < message_index:
            # if no response from server for 3 minutes, shut down entire connection raise error
            if int(time.time()) - shutdown_timeout_val >= 180:
                raise ConnectionError("Error connecting to server - aborting")
            # if no ack in 1 minute, break receive loop, begin resending from oldest unacked packet
            elif int(time.time()) - timeout_val >= 60:
                break
            # handle retransmission triggered by 3 duplicate acks
            if duplicate_acks >= 3:
                # sort sent acks by earliest non-acked packet
                # reset congestion window to 1
                CWND = 1
                # set duplicate acks back to 0 and try again
                duplicate_acks = 0
                break

            recv_sock.settimeout(60)
            # receive messages and filter out bad messages or messages not for us
            try:
                data = recv_sock.recv(RECV_SIZE)
                ack_num, seq_num, types, tcp_payload, message = readPacket(data, destination_ip, port)
            except ValueError as e:
                # if we get a bad packet, do not account for packet, reset timeout vals since connection
                # is not dead, continue receiving packets
                if str(e) == 'BAD_PACKET':
                    timeout_val = int(time.time())
                    shutdown_timeout_val = int(time.time())
                continue
            # if socket times out, reduce congestion window size to 1, break out and retry sending packets
            except socket.timeout:
                CWND = 1
                break


            # if socket times out, break looking for packets, continue below to find most
            # oldest unacked packet and begin retransmitting from there

            # check to see if there is an ack corresponding to a sent packet
            for i in range(len(sent_packets)):
                # if ack is corresponding, mark index, increase congestion window by 1 and stop searching
                if sent_packets[i][1] == ack_num:
                    # if an ack has already been received for this packet, is a duplicate ack, increase
                    # number of duplicate acks by 1
                    if sent_packets[i][3]:
                        duplicate_acks += 1
                    # otherwise, is first ack for this packet, mark packet as acked, set duplicate acks to 0
                    else:
                        sent_packets[i][3] = True
                        duplicate_acks = 0
                        # indicate an ack has been received
                    confirmed_index += 1
                    # increase congestion window size by 1
                    if CWND <= 1000:
                        CWND += 1
                    break
        # look for any unacked packets
        sent_packets.sort(key=sortByFirst)
        # find the most recently unacked packet and set message index and ack num to start from
        # unacked packet
        unacked = False
        for i in range(len(sent_packets)):
            if sent_packets[i][3] == False:
                message_index = sent_packets[i][2]
                ACK_NUM = sent_packets[i][0]
                unacked = True
                break
        # if no unacked packets, set ACK_NUM to the next packet that the server is expecting
        if not unacked and len(sent_packets) > 0:
            ACK_NUM = sent_packets[-1][1]


def receiveRequest(send_sock, recv_sock, machine_host, destination_ip, port):
    '''

    :param send_sock:
    :param recv_sock:
    :param machine_host:
    :param destination_ip:
    :param port:
    :return:
    '''
    global SEQ_NUM

    expected_seq = SEQ_NUM

    # if no response from server in 180 seconds, sever connection
    shutdown_timeout_val = int(time.time())
    # if no response from server in 60 seconds, retry
    timeout_val = int(time.time())

    # holds packets
    packets = []
    # number of packets that have been acked
    ack_index = 0
    fin_found = False
    fin_sent = False
    while True:
        # set timeout for 60 seconds
        recv_sock.settimeout(60)
        try:
            while True:
                # if no response for 3 minutes, raise error
                if int(time.time()) - shutdown_timeout_val >= 180:
                    raise ConnectionError("Error connecting to server - aborting")
                # if no response for 1 minute, send dup ack and retry
                if int(time.time()) - timeout_val >= 60:
                    ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, expected_seq, ["ACK"], "")
                    send_sock.sendto(ack_packet, (destination_ip, 0))
                    continue

                # print(seq_nums)
                data = recv_sock.recv(RECV_SIZE)

                # read the packet read from the server
                try:
                    ack_num, seq_num, types, tcp_payload, message = readPacket(data, destination_ip, port)
                # if BAD_PACKET, packet was corrupted (bad ip checksum, tcp checksum, protocol)
                # otherwise, not destined for this program (via port)
                except ValueError as e:
                    if str(e) == 'BAD_PACKET':
                        ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, expected_seq, ["ACK"], "")
                        send_sock.sendto(ack_packet, (destination_ip, 0))
                        # even if packet is bad, still a response, reset shutdown timeout and retry timeout
                        shutdown_timeout_val = int(time.time())
                        timeout_val = int(time.time())
                    continue

                # good packet, reset shutdown_timeout_val and timeout_val
                shutdown_timeout_val = int(time.time())
                timeout_val = int(time.time())

                # determine the next sequence number to be expected from the sender after current packet
                next_seq = seq_num + tcp_payload

                # if seq num does match what was expected, search for next correct gap in the sequence and
                # set expected to send dup ack to server
                if seq_num != expected_seq:
                    # search for next missing packet
                    i = ack_index
                    while i < len(packets) - 1:
                        # if there is a gap in the sequence, there is a missing packet, set expected sequence
                        # to be the next packet that should be received - sent in next ack
                        if packets[i][1] != packets[i+1][0]:
                            expected_seq = packets[i][1]
                            break
                        i += 1
                    # if I reached the end of the sequence, no more gaps, set expected_seq to next value to receive
                    # from the server
                    if i >= len(packets):
                        expected_seq = packets[-1][1]
                    ack_index = i
                # otherwise, advance sequence number and look for next good packet
                else:
                    expected_seq = next_seq
                    ack_index += 1

                # if not the fin packet, place packet into packet array
                if 'FIN' not in types:
                    # if the current packet is not the next packet in entire sequence, place into correct
                    # spot
                    if len(packets) > 0 and packets[-1][1] != seq_num:
                        for i in range(ack_index, len(packets) - 1):
                            # if previous packet next seq is less than or equal to current sequence seq
                            # and next packets seq sum is greater than or equal to current next seq,
                            # is correct place, place in correct position
                            if packets[i][1] <= seq_num and packets[i + 1][0] >= next_seq:
                                packets.insert(i + 1, (seq_num, next_seq, message))
                                break
                    # otherwise, is next packet in entire sequence, append
                    else:
                        packets.append((seq_num, next_seq, message))

                # if the finish packet is found, mark last http response in request has been received,
                # store fin packet number
                if 'FIN' in types and not fin_found:
                    # mark fin as found -- once all other packets are counted for, will break receive loop
                    fin_found = True
                    # determine the fin sequence number to return to the server
                    fin_seq = seq_num + tcp_payload + 1
                    # if the next expected packet is the fin packet, immediately send ack for fin
                    if expected_seq + 1 == fin_seq:
                        expected_seq = fin_seq
                        # send ack for server fin
                        ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, fin_seq, ["ACK"], "")
                        send_sock.sendto(ack_packet, (destination_ip, 0))
                        # indicate that the ack for the fin has already been sent
                        fin_sent = True

                    # append the fin ack sequence to seq_nums for verification of entire message received
                    packets.append((seq_num, fin_seq, message))
                    # break out of receive loop and verify all packets have been received
                    break

                # Send ACK with the next expected packet in the sequence
                ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, expected_seq, ["ACK"], "")
                send_sock.sendto(ack_packet, (destination_ip, 0))

                # if the last packet has been found, break while loop and verify whether or not all packets
                # have been received
                if fin_found:
                    break
        # if waiting for socket response times out, resend ack and try again
        except socket.timeout:
            ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, expected_seq, ["ACK"], "")
            send_sock.sendto(ack_packet, (destination_ip, 0))
            continue

        # if fin has been found and expected sequence value is the next value of the last packet, all packets
        # have been received
        # otherwise, continue receiving
        if fin_found and expected_seq == packets[-1][1]:
            break

    # if the ack for the fin packet has not already been sent, send ack
    if not fin_sent:
        # send back ack to respond to FIN packet
        ack_packet = makePacket(machine_host, destination_ip, port, 80, ACK_NUM, fin_seq, ["ACK"], "")
        send_sock.sendto(ack_packet, (destination_ip, 0))

        # reset timeout_val to prevent multiple timeouts for same timeout
        timeout_val = int(time.time())

    # set gloabl SEQ_NUM to last sequence value for return FIN/ACK
    SEQ_NUM = fin_seq

    # return packets
    return packets


# key function for sorting a packet by its sequence number (first member of packet tuple)
def sortByFirst(packet):
    return packet[0]


def download(packets, filename):
    '''
    Download the webpage or file and save in current directory
    Use the specified extension of the file if provided (ex: project.php)
    Otherwise use default 'index.html'
    :return: N/A
    '''

    # convert encoded data using utf-8
    try:
        data = ''
        for packet in packets:
            data += packet[2].decode('utf-8')
        # if not a good http response, print error, back out of function, DO NOT DOWNLOAD
        if '200 OK' not in data:
            raise ValueError('Error: Bad HTTP response')

        # determine where the http response header ends and the html/text begins
        index = 0
        for i in range(len(data)):
            # this is where the html begins (read:: fun)
            if data[i] == '<':
                break
            # first instance of this pattern indicates end of head
            elif data[i:i + 4] == '\r\n\r\n':
                index = i + 4

        # truncate header
        data = data[index:]

        f = open(filename, 'w+')
        f.write(data)
        f.close()
    # otherwise, is non-utf-8-bytes object, parse for header and do not parse body, store as binary
    except ValueError as e:
        # if previous block raised bad http response, do not execute following block
        if str(e) != 'Error: Bad HTTP response':
            # search the packets and look for the initial header (should be in utf-8)
            # once header has been found, record number of bytes in header, convert header to string
            # evaluate http status
            header_found = False
            header_data = ''
            header_byte_len = 0
            while not header_found:
                # iterate through packets in case header came in multiple packets
                for packet in packets:
                    # get bytes from packet
                    header_bytes = packet[2]
                    # serach bytes in packet for pieces of header
                    for i in range(len(header_bytes)):
                        # increase number of header bytes
                        header_byte_len += 1
                        # decode byte
                        header_data += header_bytes[i:i+1].decode('utf-8')
                        # if last 4 chars recorded are \r\n\r\n, is end of header, break and cease recording
                        if len(header_data) >= 4 and header_data[-4:] == '\r\n\r\n':
                            header_found = True
                            break
                    if header_found:
                        break

            # if not 200 response from server, bad request, exit
            if '200 OK' not in header_data:
                raise ValueError('Error: Bad HTTP response')

            # join all bytes in packets
            packet_data = []
            for packet in packets:
                packet_data.append(packet[2])
            # join all bytes
            data = b''.join(packet_data)
            # remove header from bytes
            data = data[header_byte_len:]

            # write file as binary
            f = open(filename, 'wb+')
            f.write(data)
            f.close()
        # otherwise, is http response error, raise error to fucntion caller
        else:
            raise e


def run():
    '''
    Execute the program
    :return: N/A
    '''

    try:
        # create sending raw socket
        send_sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
        # create receiving raw socket
        recv_sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
    except socket.error as msg:
        print('Socket could not be created. Error code: ' + str(msg[0]) + ' Message ' + msg[1])
        return

    # if not sufficient command line args, back out
    if len(sys.argv) < 2:
        print("Error: insufficient command line args")
        return

    # parse the hostname and resource being downloaded from command line args
    url = sys.argv[1]
    url_vals = url.split('/')
    # if http or https in header, parse these out
    if 'http' in url_vals[0] or 'https' in url_vals[0]:
        url_vals = url_vals[2:]

    # remove any elements in url_vals that are empty strings (useless)
    good_vals = []
    for each in url_vals:
        if each != '':
            good_vals.append(each)
    url_vals = good_vals

    # get destination name
    dest_name = url_vals[0]

    # find the resource name, if one exists
    if len(url_vals) > 1:
        uri = '/' + '/'.join(url_vals[1:])
    # otherwise, get page hostname points to
    else:
        uri = '/'

    # get IP for host machine
    host_str = str(check_output(['hostname', '-I']))
    host_vals = host_str.split("'")
    host_vals = host_vals[1].split()
    machine_host = host_vals[0]
    # try to find destination ip address with destination name
    # if unavailable, print error and exit
    try:
        destination_ip = socket.gethostbyname(dest_name)
    except socket.error:
        print("Error: Could not validate host")

    # choose random port and check if it is available
    port = random.randint(1024, 65535)
    # checks if port is already being used by system
    while True:
        # tries to open and bind a connection on specific port to check if available
        try:
            # if it is available, print it is a good port and proceed with
            # program execution
            location = (machine_host, port)
            a_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            a_sock.bind(location)
            a_sock.listen(5)
            result_of_check = a_sock.connect_ex(location)
            a_sock.close()
            break
        # otherwise it will be a socket error and will set port to new random number
        # and repeat
        except socket.error as e:
            port = random.randint(1024, 65535)

    # begin transmitting
    try:
        # connection setup
        handshake(send_sock, recv_sock, machine_host, destination_ip, port)

        # create HTTP GET request
        http_mess = 'GET ' + uri + ' HTTP/1.0\r\nHost: ' + dest_name + \
                    '\r\nConnection: keep-alive' + \
                    '\r\nUpgrade-Insecure-Requests: 1' + \
                    '\r\nAccept-Language: en-US,en;q=0.5' + \
                    '\r\nAccept-Encoding: compress' + \
                    '\r\nAccept: image/webp,*/*' + \
                    '\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0' + \
                    '\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'

        # send the GET request
        sendRequest(send_sock, recv_sock, machine_host, destination_ip, port, http_mess)
        # receive response from get request
        packets = receiveRequest(send_sock, recv_sock, machine_host, destination_ip, port)
        # finish tearing down connection
        teardown(send_sock, recv_sock, machine_host, destination_ip, port)
    # if there is a connection error, print error to screen and exit
    except ConnectionError as e:
        print(str(e))
        return

    # if the uri is single slash, name file 'index.html'
    if uri == '/':
        filename = 'index.html'
    # otherwise, keep given name
    else:
        filename = url_vals[-1]

    # download the file
    try:
        download(packets, filename)
    # if error while downloading, print error and exit
    except ValueError as e:
        print(str(e))
        return


run()
