from tclGenerator import experimentString
from experimentUtils import getCurrentPath, createShortPath, createLongPath, \
                            writeAndRunTCL, getRandomStart
import os
import sys


def experimentOne(cwd):
    exp = "exp_one"
    shortPath = createShortPath(cwd, exp)
    longPath = createLongPath(cwd, exp)

    spans = [[0, 18], [0, 63]]
    expAgents = ["", "/Reno", "/Newreno", "/Vegas"]
    expCbrFlow = ["1Mb", "2.5Mb", "5Mb", "9Mb"]
    expOneLen = 10
    # do first set of times 0 -> 5
    for span in spans:
        for cbrFlow in expCbrFlow:
            for expAgent in expAgents:
                # make dir for current experiment
                if expAgent != "":
                    dirInfo = "%s_%s" % (expAgent, cbrFlow)
                else:
                    dirInfo = "/Tahoe_%s" % cbrFlow

                dirPath = getCurrentPath(span, spans, shortPath, longPath, dirInfo)

                trFiles = []
                currExp = 0
                while currExp < expOneLen:
                    tcpStart = getRandomStart()
                    expInfo = "%s_%s" % (expAgent, cbrFlow)

                    # get experiment string
                    traceDir = "%s/%s_#%d.tr" % (dirPath, expInfo, currExp)
                    expString = experimentString(traceDir, expAgent, None, cbrFlow, tcpStart, span[1] - 1,
                                                 span[0], span[1], 25, "DropTail")
                    trFiles.append(traceDir)
                    writeAndRunTCL(dirPath, expInfo, currExp, expString)
                    currExp += 1

                # analyze(dirPath)
                for trFile in trFiles:
                    os.system("rm %s" % trFile)


def experimentTwo(cwd):
    exp = "exp_two"
    shortPath = createShortPath(cwd, exp)
    longPath = createLongPath(cwd, exp)

    spans = [[0, 18], [0, 63]]
    expAgents = [["/Reno", "/Reno"], ["/Newreno", "/Reno"], ["/Vegas", "/Vegas"], ["/Newreno", "/Vegas"]]
    expCbrFlow = ["1Mb", "2.5Mb", "5Mb", "9Mb"]
    expLen = 10
    # do first set of times 0 -> 5
    for span in spans:
        for cbrFlow in expCbrFlow:
            for expAgent in expAgents:
                # make dir for current experiment
                dirInfo = "%s_%s_%s" % (expAgent[0][1:], expAgent[1][1:], cbrFlow)
                dirPath = getCurrentPath(span, spans, shortPath, longPath, dirInfo)

                currExp = 0
                while currExp < expLen:
                    # vary start time
                    tcp_start = getRandomStart()
                    expInfo = "%s_%s_%s" % (expAgent[0][1:], expAgent[1][1:], cbrFlow)

                    # get experiment string
                    trace_dir = "%s/%s_#%d.tr" % (dirPath, expInfo, currExp)
                    expString = experimentString(trace_dir, expAgent[0], expAgent[1], cbrFlow, tcp_start, span[1] - 1,
                                                 span[0], span[1], 25, "DropTail")

                    writeAndRunTCL(dirPath, expInfo, currExp, expString)
                    currExp += 1


def experimentThree(cwd):
    exp = "exp_three"
    shortPath = createShortPath(cwd, exp)
    longPath = createLongPath(cwd, exp)

    spans = [[0, 23], [0, 68]]
    expOneAgents = ["/Reno", "/Sack1"]
    queueMech = ["DropTail", "RED"]
    queueSize = [15, 20, 25, 35]
    expLen = 5
    # do first set of times 0 -> 5
    for span in spans:
        for size in queueSize:
            for expAgent in expOneAgents:
                for mech in queueMech:
                    # make dir for current experiment
                    dirInfo = "%s_%s_%s" % (expAgent, mech, size)
                    dirPath = getCurrentPath(span, spans, shortPath, longPath, dirInfo)

                    currExp = 0
                    while currExp < expLen:
                        # vary start time
                        cbr_start = getRandomStart(span) + 5

                        expInfo = "%s_%d" % (expAgent, size)

                        # get experiment string
                        trace_dir = "%s/%s_#%d.tr" % (dirPath, expInfo, currExp)
                        expString = experimentString(trace_dir, expAgent, None, "5Mb", span[0], span[1],
                                                     cbr_start, span[1] - 1, size, mech)

                        writeAndRunTCL(dirPath, expInfo, currExp, expString)
                        currExp += 1


def test():
    cwd = os.getcwd()
    expString = experimentString(str(cwd + "/test.tr"), "/Reno", None, "2Mb", 1, 16,
                                 0, 17, 25, "DropTail")

    # creat tcl file
    tclFile = "%s/test.tcl" % cwd
    f = open(tclFile, "w+")
    f.write(expString)
    f.close()

    os.system("/course/cs4700f12/ns-allinone-2.35/bin/ns %s" % tclFile)


def test2():
    cwd = os.getcwd()
    expString = experimentString(str(cwd + "/test2.tr"), "/Reno", "/Reno", "2Mb", 1, 16,
                                 0, 17, 25, "DropTail")

    # creat tcl file
    tclFile = "%s/test2.tcl" % cwd
    f = open(tclFile, "w+")
    f.write(expString)
    f.close()

    os.system("/course/cs4700f12/ns-allinone-2.35/bin/ns %s" % tclFile)


def test3():
    cwd = os.getcwd()
    expString = experimentString(str(cwd + "/test3.tr"), "/Reno", None, "2Mb", 1, 16,
                                 0, 17, 25, "RED")

    # creat tcl file
    tclFile = "%s/test3.tcl" % cwd
    f = open(tclFile, "w+")
    f.write(expString)
    f.close()

    os.system("/course/cs4700f12/ns-allinone-2.35/bin/ns %s" % tclFile)


def run():
    cwd = os.getcwd()

    if "1" in sys.argv:
        experimentOne(cwd)
    if "2" in sys.argv:
        experimentTwo(cwd)
    if "3" in sys.argv:
        experimentThree(cwd)
    if "t" in sys.argv:
        test()
    if "t2" in sys.argv:
        test2()
    if "t3" in sys.argv:
        test3()


run()
