import os
import random


def getCurrentPath(span, spans, shortPath, longPath, dirInfo):
    if span[1] < spans[1][1]:
        dirPath = "%s/%s" % (shortPath, dirInfo)
    else:
        dirPath = "%s/%s" % (longPath, dirInfo)

    if not os.path.exists(dirPath):
        os.mkdir(dirPath)

    return dirPath


def createTopPath(cwd, expNum):
    expPath = "%s/%s" % (cwd, expNum)
    if not os.path.exists(expPath):
        os.mkdir(expPath)

    return expPath


def createShortPath(cwd, expNum):
    expPath = createTopPath(cwd, expNum)

    shortPath = "%s/short" % expPath
    if not os.path.exists(shortPath):
        os.mkdir(shortPath)

    return shortPath


def createLongPath(cwd, expNum):
    expPath = createTopPath(cwd, expNum)

    longPath = "%s/long" % expPath
    if not os.path.exists(longPath):
        os.mkdir(longPath)

    return longPath


def writeAndRunTCL(dirPath, expInfo, currExp, experimentString):
    # creat tcl file
    tclFile = "%s/%s_#%d.tcl" % (dirPath, expInfo, currExp)
    f = open(tclFile, "w+")
    f.write(experimentString)
    f.close()

    os.system("/course/cs4700f12/ns-allinone-2.35/bin/ns %s" % tclFile)


def getRandomStart():
    random.seed()
    return random.uniform(1, 2)

