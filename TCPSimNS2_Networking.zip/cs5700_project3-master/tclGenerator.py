# this script will programatically generate TCP scripts

CBR_PACKET_SIZE = 1000
LINK_DELAY = 2
LINK_BANDWIDTH = 10


def experimentString(trace_dir, tcp1_agent, tcp2_agent, cbr_flow, tcp_start,
                     tcp_end, cbr_start, cbr_end, queue_size, queue_mech):
    # create simulator
    tclString = '#Creating Simulator Object\n'
    tclString += 'set ns [new Simulator]\n\n'

    # create trace file
    tclString += '#open trace file\n'
    tclString += 'set ntrace [open %s w]\n' % trace_dir
    tclString += '$ns trace-all $ntrace\n\n'

    # create finish procedure
    tclString += '#define a \'finish\' protocol\n'
    tclString += 'proc finish {} {\n'
    tclString += '      global ns ntrace\n'
    tclString += '      $ns flush-trace\n'
    tclString += '      close $ntrace\n'
    tclString += '      exit 0\n'
    tclString += '}\n\n'

    # create nodes
    tclString += '#create nodes\n'
    tclString += 'set n1 [$ns node]\n'
    tclString += 'set n2 [$ns node]\n'
    tclString += 'set n3 [$ns node]\n'
    tclString += 'set n4 [$ns node]\n'
    tclString += 'set n5 [$ns node]\n'
    tclString += 'set n6 [$ns node]\n\n'

    # create links
    tclString += '#create duplex links\n'
    tclString += '$ns duplex-link $n1 $n2 %dMb %dms %s\n' % (LINK_BANDWIDTH, LINK_DELAY, queue_mech)
    tclString += '$ns duplex-link $n5 $n2 %dMb %dms %s\n' % (LINK_BANDWIDTH, LINK_DELAY, queue_mech)
    tclString += '$ns duplex-link $n2 $n3 %dMb %dms %s\n' % (LINK_BANDWIDTH, LINK_DELAY, queue_mech)
    tclString += '$ns duplex-link $n3 $n4 %dMb %dms %s\n' % (LINK_BANDWIDTH, LINK_DELAY, queue_mech)
    tclString += '$ns duplex-link $n3 $n6 %dMb %dms %s\n\n' % (LINK_BANDWIDTH, LINK_DELAY, queue_mech)

    # create queue size
    tclString += '#set queue size of n2-n3 link\n'
    tclString += '$ns queue-limit $n1 $n2 %d\n' % queue_size
    tclString += '$ns queue-limit $n2 $n3 %d\n' % queue_size
    tclString += '$ns queue-limit $n3 $n4 %d\n' % queue_size
    tclString += '$ns queue-limit $n5 $n2 %d\n' % queue_size
    tclString += '$ns queue-limit $n3 $n6 %d\n' % queue_size

    # create tcp connection for first tcp agent
    tclString += '#setup tcp connection from n1 to n4\n'
    tclString += 'set tcp1 [new Agent/TCP%s]\n' % tcp1_agent
    tclString += '$ns attach-agent $n1 $tcp1\n'
    tclString += 'set sink [new Agent/TCPSink]\n'
    tclString += '$ns attach-agent $n4 $sink\n'
    tclString += '$ns connect $tcp1 $sink\n'
    tclString += '$tcp1 set fid_ 1\n\n'

    # set FTP over TCP connection for first tcp agent
    tclString += '#set FTP over TCP\n'
    tclString += 'set ftp1 [new Application/FTP]\n'
    tclString += '$ftp1 attach-agent $tcp1\n'
    tclString += '$ftp1 set type_ FTP\n\n'

    if tcp2_agent is not None:
        # create tcp connection for second tcp agent
        tclString += '#setup tcp connection from n5 to n6\n'
        tclString += 'set tcp2 [new Agent/TCP%s]\n' % tcp2_agent
        tclString += '$ns attach-agent $n5 $tcp2\n'
        tclString += 'set sink [new Agent/TCPSink]\n'
        tclString += '$ns attach-agent $n6 $sink\n'
        tclString += '$ns connect $tcp2 $sink\n'
        tclString += '$tcp2 set fid_ 2\n\n'

        # set FTP over TCP connection for second tcp agent
        tclString += '#set FTP over TCP\n'
        tclString += 'set ftp2 [new Application/FTP]\n'
        tclString += '$ftp2 attach-agent $tcp2\n'
        tclString += '$ftp2 set type_ FTP\n\n'

    # if tcp start greater than cbr, is exp 1 or 2
    if tcp_start > cbr_start:
        # set udp connection
        tclString += '#set UDP connection\n'
        tclString += 'set udp [new Agent/UDP]\n'
        tclString += '$ns attach-agent $n2 $udp\n'
        tclString += 'set null [new Agent/Null]\n'
        tclString += '$ns attach-agent $n3 $null\n'
        tclString += '$ns connect $udp $null\n\n'
    # otherwise, is exp 3, set cbr from n5-n6
    else:
        # set udp connection
        tclString += '#set UDP connection\n'
        tclString += 'set udp [new Agent/UDP]\n'
        tclString += '$ns attach-agent $n5 $udp\n'
        tclString += 'set null [new Agent/Null]\n'
        tclString += '$ns attach-agent $n6 $null\n'
        tclString += '$ns connect $udp $null\n\n'

    # setup CBR over UDP connection
    tclString += '#set CBR over UDP connection\n'
    tclString += 'set cbr [new Application/Traffic/CBR]\n'
    tclString += '$cbr set packet_size_ %d \n' % CBR_PACKET_SIZE
    tclString += '$cbr set rate_ %s\n' % cbr_flow
    tclString += '$cbr attach-agent $udp\n\n'

    # if tcp starts before cbr, is exp 1 or 2
    if tcp_start > cbr_start:
        # schedule events for CBR and FTP flows
        tclString += '#schedule events for flows\n'
        tclString += '$ns at %d "$cbr start"\n' % cbr_start
        tclString += '$ns at %f "$ftp1 start"\n' % tcp_start

        # if tcp_agent 2 is not none, is exp 2
        if tcp2_agent is not None:
            tclString += '$ns at %f "$ftp2 start"\n' % tcp_start
            tclString += '$ns at %f "$ftp2 stop"\n' % tcp_end

        tclString += '$ns at %f "$ftp1 stop"\n' % tcp_end
        tclString += '$ns at %d "$cbr stop"\n\n' % cbr_end

        # finish the program
        tclString += '#finsih the program\n'
        tclString += '$ns at %d "finish"\n\n' % (cbr_end + 1)
    # otherwise, is exp 3, start tcp before cbr
    else:
        # schedule events for CBR and FTP flows
        tclString += '#schedule events for flows\n'
        tclString += '$ns at %d "$ftp1 start"\n' % tcp_start
        tclString += '$ns at %f "$cbr start"\n' % cbr_start
        tclString += '$ns at %f "$cbr stop"\n' % cbr_end
        tclString += '$ns at %d "$ftp1 stop"\n\n' % tcp_end

        # finish the program
        tclString += '#finsih the program\n'
        tclString += '$ns at %d "finish"\n\n' % (tcp_end + 1)

    tclString += 'proc getCwnd {tcp traceFile} {\n'
    tclString += '      global ns\n'
    tclString += '      set curr [$ns now]\n'
    tclString += '      set cwnd [$tcp set cwnd_]\n'
    tclString += '      puts $traceFile "$tcp $curr $cwnd"\n'
    tclString += '      $ns at [expr $curr+0.1] "getCwnd $tcp $traceFile"\n'
    tclString += '}\n\n'

    tclString += '$ns at %f "getCwnd $tcp1 $ntrace"\n\n' % tcp_start

    if tcp2_agent is not None:
        tclString += '$ns at %f "getCwnd $tcp2 $ntrace"\n\n' % tcp_start

    # run the sim
    tclString += '#run the sim\n'
    tclString += '$ns run\n'

    return tclString
