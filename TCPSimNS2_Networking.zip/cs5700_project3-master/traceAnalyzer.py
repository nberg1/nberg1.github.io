import os
import sys
import math

TIME = 0

def analyzeExperimentOne():

    cwd = os.getcwd()

    # get tcl file
    localFile = "test.tcl"
    tclFile = "%s/%s" % (cwd, localFile)
    f = open(tclFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")
    linkBandwidthLine = 0
    queueLimitLine = 0
    startLine = 0
    stopLine = 0
    endLine = 0
    lineIndex = 0
    for line in lines:
        if "duplex-link" in line:
            linkBandwidthLine = lineIndex
        if "queue-limit" in line:
            queueLimitLine = lineIndex
        if "start" in line and "ftp" in line:
            startLine = lineIndex
        if "stop" in line and "ftp" in line:
            stopLine = lineIndex
        if "stop" in line and "cbr" in line:
            endLine = lineIndex
        lineIndex += 1

    linkBandwidth = int(lines[linkBandwidthLine].split(" ")[4][:-2])
    linkDelay = lines[linkBandwidthLine].split(" ")[5]
    queueLimit = lines[queueLimitLine].split(" ")[4]
    start = float(lines[startLine].split(" ")[2])
    stop = float(lines[stopLine].split(" ")[2])
    end = int(lines[endLine].split(" ")[2])

    # get trace file
    localFile = "test.tr"
    trFile = "%s/%s" % (cwd, localFile)

    f = open(trFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")

    sequenceDict = {}

    for line in lines:
        lineVals = line.split(" ")
        if len(lineVals) != 12 or "cbr" in line:
            continue

        if lineVals[10] not in sequenceDict:
            sequenceDict[lineVals[10]] = []
            sequenceDict[lineVals[10]].append(line)
        else:
            sequenceDict[lineVals[10]].append(line)

    dropSequenceStr = ""
    sequenceStr = ""
    times = []
    for sequence in sequenceDict:
        hasDrop = False
        currSeq = "Sequence :" + sequence + "\n"
        for line in sequenceDict[sequence]:
            if line.split(" ")[0] == "d":
                hasDrop = True
            currSeq += line + '\n'
        currSeq += '\n'
        if hasDrop:
            dropSequenceStr += currSeq
        else:
            l = sequenceDict[sequence]
            time1 = float(l[0].split(" ")[1])
            time2 = float(l[-1].split(" ")[1])
            times.append(time2 - time1)
            sequenceStr += currSeq

    totalTime = 0
    for time in times:
        totalTime += time
    TIME = totalTime
    averageTime = totalTime/len(times)

    bdp = linkBandwidth * averageTime

    # calculate average bandwidth
    bytesPerSecond = [0] * (end + 1)
    tcpBytesPerSecond = [0] * (end + 1)
    cbrBytesPerSecond = [0] * (end + 1)
    for line in lines:
        vals = line.split(" ")
        if len(vals) < 12:
            continue
        bits = int(vals[5])
        time = float(vals[1])

        if start <= time <= stop:
            sec = int(time)
            bytesPerSecond[sec] += bits
            if "tcp" in vals[4] and "r" in vals[0] and "3" in vals[3]:
                tcpBytesPerSecond[sec] += bits
            elif "cbr" in vals[4] and "r" in vals[0] and "2" in vals[3]:
                cbrBytesPerSecond[sec] += bits

    totalBytes = 0
    for byteVal in tcpBytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageTCPThroughput = totalMegaBits/totalTime

    totalBytes = 0
    for byteVal in cbrBytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageCBRThroughput = totalMegaBits/totalTime

    totalStr = "Average TCP throughput: " + str(averageTCPThroughput) + "Mbps\n"
    totalStr += "Average UDP bandwidth: " + str(averageCBRThroughput) + "Mbps\n"
    totalStr += "Average RTT: " + str(averageTime) + "\n"
    totalStr += "Link bandwidth: " + str(linkBandwidth) + "Mbps\n"
    totalStr += "Link delay : " + linkDelay + "\n"
    totalStr += "Queue limit: " + queueLimit + "\n"
    totalStr += "BDP: " + str(bdp) + "Mbps\n"
    totalStr += "Time of experiment: " + str(totalTime) + " seconds \n\n"
    totalStr += "Good Sends:\n\n" + sequenceStr + "\n\nDropped:\n\n" + dropSequenceStr

    localFile = "test.txt"
    dataFile = "%s/%s" % (cwd, localFile)
    f = open(dataFile, "w+")
    f.write(totalStr)
    f.close()

def analyzeExperimentTwo():

    cwd = os.getcwd()

    # get tcl file
    localFile = "test2.tcl"
    tclFile = "%s/%s" % (cwd, localFile)
    f = open(tclFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")
    linkBandwidthLine = 0
    queueLimitLine = 0
    startLine = 0
    stopLine = 0
    endLine = 0
    lineIndex = 0
    for line in lines:
        if "duplex-link" in line:
            linkBandwidthLine = lineIndex
        if "queue-limit" in line:
            queueLimitLine = lineIndex
        if "start" in line and "ftp1" in line:
            startLine = lineIndex
        if "stop" in line and "ftp1" in line:
            stopLine = lineIndex
        if "stop" in line and "cbr" in line:
            endLine = lineIndex
        lineIndex += 1

    linkBandwidth = int(lines[linkBandwidthLine].split(" ")[4][:-2])
    linkDelay = lines[linkBandwidthLine].split(" ")[5]
    queueLimit = lines[queueLimitLine].split(" ")[4]
    start = float(lines[startLine].split(" ")[2])
    stop = float(lines[stopLine].split(" ")[2])
    end = int(lines[endLine].split(" ")[2])

    # get trace file
    localFile = "test2.tr"
    trFile = "%s/%s" % (cwd, localFile)

    f = open(trFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")

    sequenceDict1 = {}
    sequenceDict2 = {}

    for line in lines:
        lineVals = line.split(" ")
        if len(lineVals) != 12 or "cbr" in line:
            continue

        if "3.0" in lineVals[9]:
            if lineVals[10] not in sequenceDict1:
                sequenceDict1[lineVals[10]] = []
                sequenceDict1[lineVals[10]].append(line)
            else:
                sequenceDict1[lineVals[10]].append(line)
        elif "5.0" in lineVals[9]:
            if lineVals[10] not in sequenceDict2:
                sequenceDict2[lineVals[10]] = []
                sequenceDict2[lineVals[10]].append(line)
            else:
                sequenceDict2[lineVals[10]].append(line)

    dropSequenceStr = ""
    sequenceStr = ""
    times = []
    for sequence in sequenceDict1:
        hasDrop = False
        currSeq = "Sequence :" + sequence + "\n"
        for line in sequenceDict1[sequence]:
            if line.split(" ")[0] == "d":
                hasDrop = True
            currSeq += line + '\n'
        currSeq += '\n'
        if hasDrop:
            dropSequenceStr += currSeq
        else:
            l = sequenceDict1[sequence]
            time1 = float(l[0].split(" ")[1])
            time2 = float(l[-1].split(" ")[1])
            times.append(time2 - time1)
            sequenceStr += currSeq

    for sequence in sequenceDict2:
        hasDrop = False
        currSeq = "Sequence :" + sequence + "\n"
        for line in sequenceDict2[sequence]:
            if line.split(" ")[0] == "d":
                hasDrop = True
            currSeq += line + '\n'
        currSeq += '\n'
        if hasDrop:
            dropSequenceStr += currSeq
        else:
            l = sequenceDict2[sequence]
            time1 = float(l[0].split(" ")[1])
            time2 = float(l[-1].split(" ")[1])
            times.append(time2 - time1)
            sequenceStr += currSeq

    totalTime = 0
    for time in times:
        totalTime += time
    averageTime = totalTime/len(times)

    bdp = linkBandwidth * averageTime

    # calculate average bandwidth
    bytesPerSecond = [0] * (end + 1)
    tcp1BytesPerSecond = [0] * (end + 1)
    tcp2BytesPerSecond = [0] * (end + 1)
    cbrBytesPerSecond = [0] * (end + 1)
    for line in lines:
        vals = line.split(" ")
        if len(vals) < 12:
            continue
        bits = int(vals[5])
        time = float(vals[1])

        if start <= time <= stop:
            sec = int(time)
            bytesPerSecond[sec] += bits
            if "tcp" in vals[4] and "r" in vals[0] and "3" in vals[3] and "3.0" in vals[9]:
                tcp1BytesPerSecond[sec] += bits
            elif "tcp" in vals[4] and "r" in vals[0] and "5" in vals[3] and "5.0" in vals[9]:
                tcp2BytesPerSecond[sec] += bits
            elif "cbr" in vals[4] and "r" in vals[0] and "2" in vals[3]:
                cbrBytesPerSecond[sec] += bits

    totalBytes = 0
    for byteVal in tcp1BytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageTCP1Throughput = totalMegaBits/totalTime

    totalBytes = 0
    for byteVal in tcp2BytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageTCP2Throughput = totalMegaBits/totalTime

    totalBytes = 0
    for byteVal in cbrBytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageCBRThroughput = totalMegaBits/totalTime

    totalStr = "Average TCP1 throughput: " + str(averageTCP1Throughput) + "Mbps\n"
    totalStr += "Average TCP2 throughput: " + str(averageTCP2Throughput) + "Mbps\n"
    totalStr += "Average UDP bandwidth: " + str(averageCBRThroughput) + "Mbps\n"
    totalStr += "Average RTT: " + str(averageTime) + "\n"
    totalStr += "Link bandwidth: " + str(linkBandwidth) + "Mbps\n"
    totalStr += "Link delay : " + linkDelay + "\n"
    totalStr += "Queue limit: " + queueLimit + "\n"
    totalStr += "BDP: " + str(bdp) + "Mbps\n"
    totalStr += "Time of experiment: " + str(totalTime) + " seconds \n\n"
    totalStr += "Good Sends:\n\n" + sequenceStr + "\n\nDropped:\n\n" + dropSequenceStr

    localFile = "test2.txt"
    dataFile = "%s/%s" % (cwd, localFile)
    f = open(dataFile, "w+")
    f.write(totalStr)
    f.close()


def analyzeExperimentThree():

    cwd = os.getcwd()

    # get tcl file
    localFile = "test3.tcl"
    tclFile = "%s/%s" % (cwd, localFile)
    f = open(tclFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")
    linkBandwidthLine = 0
    queueLimitLine = 0
    startLine = 0
    stopLine = 0
    endLine = 0
    lineIndex = 0
    for line in lines:
        if "duplex-link" in line:
            linkBandwidthLine = lineIndex
        if "queue-limit" in line:
            queueLimitLine = lineIndex
        if "start" in line and "ftp" in line:
            startLine = lineIndex
        if "stop" in line and "ftp" in line:
            stopLine = lineIndex
        if "stop" in line and "cbr" in line:
            endLine = lineIndex
        lineIndex += 1

    linkBandwidth = int(lines[linkBandwidthLine].split(" ")[4][:-2])
    linkDelay = lines[linkBandwidthLine].split(" ")[5]
    queueLimit = lines[queueLimitLine].split(" ")[4]
    start = float(lines[startLine].split(" ")[2])
    stop = float(lines[stopLine].split(" ")[2])
    end = int(lines[endLine].split(" ")[2])

    # get trace file
    localFile = "test3.tr"
    trFile = "%s/%s" % (cwd, localFile)

    f = open(trFile, "r")
    text = f.read()
    f.close()

    lines = text.split("\n")

    sequenceDict = {}

    for line in lines:
        lineVals = line.split(" ")
        if len(lineVals) != 12 or "cbr" in line:
            continue

        if lineVals[10] not in sequenceDict:
            sequenceDict[lineVals[10]] = []
            sequenceDict[lineVals[10]].append(line)
        else:
            sequenceDict[lineVals[10]].append(line)

    dropSequenceStr = ""
    sequenceStr = ""
    times = []
    for sequence in sequenceDict:
        hasDrop = False
        currSeq = "Sequence :" + sequence + "\n"
        for line in sequenceDict[sequence]:
            if line.split(" ")[0] == "d":
                hasDrop = True
            currSeq += line + '\n'
        currSeq += '\n'
        if hasDrop:
            dropSequenceStr += currSeq
        else:
            l = sequenceDict[sequence]
            time1 = float(l[0].split(" ")[1])
            time2 = float(l[-1].split(" ")[1])
            times.append(time2 - time1)
            sequenceStr += currSeq

    totalTime = 0
    for time in times:
        totalTime += time
    averageTime = totalTime/len(times)

    bdp = linkBandwidth * averageTime

    # calculate average bandwidth
    bytesPerSecond = [0] * (end + 1)
    tcpBytesPerSecond = [0] * (end + 1)
    cbrBytesPerSecond = [0] * (end + 1)
    for line in lines:
        vals = line.split(" ")
        if len(vals) < 12:
            continue
        bits = int(vals[5])
        time = float(vals[1])

        if start <= time <= stop:
            sec = int(time)
            bytesPerSecond[sec] += bits
            if "tcp" in vals[4] and "r" in vals[0] and "3" in vals[3]:
                tcpBytesPerSecond[sec] += bits
            elif "cbr" in vals[4] and "r" in vals[0] and "2" in vals[3]:
                cbrBytesPerSecond[sec] += bits

    totalBytes = 0
    for byteVal in tcpBytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageTCPThroughput = totalMegaBits/totalTime

    totalBytes = 0
    for byteVal in cbrBytesPerSecond:
        totalBytes += byteVal

    totalMegaBits = (8 * totalBytes)/1000000
    totalTime = stop - start
    averageCBRThroughput = totalMegaBits/totalTime

    totalStr = "Average TCP throughput: " + str(averageTCPThroughput) + "Mbps\n"
    totalStr += "Average UDP bandwidth: " + str(averageCBRThroughput) + "Mbps\n"
    totalStr += "Average RTT: " + str(averageTime) + "\n"
    totalStr += "Link bandwidth: " + str(linkBandwidth) + "Mbps\n"
    totalStr += "Link delay : " + linkDelay + "\n"
    totalStr += "Queue limit: " + queueLimit + "\n"
    totalStr += "BDP: " + str(bdp) + "Mbps\n"
    totalStr += "Time of experiment: " + str(totalTime) + " seconds \n\n"
    totalStr += "Good Sends:\n\n" + sequenceStr + "\n\nDropped:\n\n" + dropSequenceStr

    localFile = "test3.txt"
    dataFile = "%s/%s" % (cwd, localFile)
    f = open(dataFile, "w+")
    f.write(totalStr)
    f.close()

def readFile(file):
    '''
    readFile reads in a trace file with trace data to be parsed for throughput and latency.
    :param file: name of text .tr trace file output to be parsed
    :return: list of strings (of each packet and data)
    '''

    packets = []
    # while file is open as an object
    with open(file) as openfileobject:
        # for each individual line in the file
        for line in openfileobject:
            # strip  trailing new lines
            line = line.strip()
            # append line to
            packets.append(line)
    return packets


def calculateThroughput(throughput_packets):
    '''
    calculates throughput for each successful packet per second
    :param throughput_packets: dictionary with key, value pair where key is floor of the second and
        value is a list of the packets sent within that timeframe
    :return:
    '''

    # will use to calculate
    throughputs = {}
    packet_totals = [0]*TIME
    for each in throughput_packets:
        packet = each.split()
        if packet[0] == 'r' and packet[2] == '2' and packet[3] == '3':
            for i in range(TIME):
                if float(packet[1]) > i and float(packet[1]) < i + 1:
                    packet_totals[i] += int(packet[5])
                    # add packets to dictionary using packet id as the key and the packet data as the value
                    # if the packet id is already in the dictionary
                    if i in throughputs:
                        # get the values in that key
                        vals = throughputs.get(i)
                        # checks to make sure no duplicate packets?
                        if packet[-1] not in vals:
                            # add the new packet to the values list
                            vals.append(each)
                    # otherwise add a new (key, value) pair to dictionary
                    else:
                        # with packet id as key and list of packet data as value
                        throughputs[i] = [each]

    for i in range(len(packet_totals)):
        packet_totals[i] *= 8
        packet_totals[i] /= (pow(10, 6))
        print('{} Mbps per second {}'.format(packet_totals[i], i))

def run():
    if "t" in sys.argv:
        analyzeExperimentOne()
    if "t2" in sys.argv:
        analyzeExperimentTwo()
    if "t3" in sys.argv:
        analyzeExperimentThree()

    # automate going through each file
    # list of files to loop through and get values
    tracefiles = []
    path_directories = []
    path_dict = {}
    # set root directory
    root_directory = '../cs5700_project3/'
    os.chdir(root_directory)
    # go through the project 3 directory and get all sub directories and files traversing down
    for subdir, dirs, files in os.walk(root_directory):
        # get the directories with the experiment .tcl and .tr trace files
        if 'exp_one' in subdir or 'exp_two' in subdir or 'exp_three' in subdir:
            # if the TCP variant names are in the directory name
            for file in files:
                # if 'Tahoe' in subdir or 'Reno' in subdir or 'Newreno' in subdir or 'Vegas' in subdir:
                if 'Newreno_1Mb' in subdir:
                    # add that directory to directory path
                    path_directories.append(os.path.join(subdir))
                    # get only the output trace files
                    if '.tr' in file:
                        tracefiles.append(os.path.join(file))
    # print(path_directories)
    # print(tracefiles)

    # for each in path_directories:
    os.chdir(path_directories[0])
    for each in tracefiles:
        # print(each)
        packets = readFile(each)
        calculateThroughput(packets)



run()
