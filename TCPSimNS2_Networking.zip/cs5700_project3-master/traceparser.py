import os
import sys
TOTAL_TIME = 10     # total time in seconds

def readFile(file):
    '''
    readFile reads in a trace file with trace data to be parsed for throughput and latency.
    :param file: name of text .tr trace file output to be parsed
    :return: list of strings (of each packet and data)
    '''

    packets = []
    # while file is open as an object
    with open(file) as openfileobject:
        # for each individual line in the file
        for line in openfileobject:
            # strip  trailing new lines
            line = line.strip()
            # append line to
            packets.append(line)
    return packets


def calculateThroughput(throughput_packets):
    '''
    calculates throughput for each successful packet per second
    :param throughput_packets: dictionary with key, value pair where key is floor of the second and
        value is a list of the packets sent within that timeframe
    :return:
    '''

    # will use to calculate
    throughputs = {}
    packet_totals = [0]*TOTAL_TIME
    for each in throughput_packets:
        packet = each.split()
        if packet[0] == 'r' and packet[2] == '2' and packet[3] == '3':
            for i in range(TOTAL_TIME):
                if float(packet[1]) > i and float(packet[1]) < i + 1:
                    packet_totals[i] += int(packet[5])
                    # add packets to dictionary using packet id as the key and the packet data as the value
                    # if the packet id is already in the dictionary
                    if i in throughputs:
                        # get the values in that key
                        vals = throughputs.get(i)
                        # checks to make sure no duplicate packets?
                        if packet[-1] not in vals:
                            # add the new packet to the values list
                            vals.append(each)
                    # otherwise add a new (key, value) pair to dictionary
                    else:
                        # with packet id as key and list of packet data as value
                        throughputs[i] = [each]

    for i in range(len(packet_totals)):
        packet_totals[i] *= 8
        packet_totals[i] = float(packet_totals[i]) / (pow(10, 6))
        print('{} Mbps per second {}'.format(packet_totals[i], i))


def main():
    # automate going through each file
    # list of files to loop through and get values
    tracefiles = []
    path_directories = []
    path_dict = {}
    # set root directory
    root_directory = '../cs5700_project3/'
    os.chdir(root_directory)
    # go through the project 3 directory and get all sub directories and files traversing down
    for subdir, dirs, files in os.walk(root_directory):
        # get the directories with the experiment .tcl and .tr trace files
        if 'exp_one' in subdir or 'exp_two' in subdir or 'exp_three' in subdir:
            # if the TCP variant names are in the directory name
            for file in files:
                # if 'Tahoe' in subdir or 'Reno' in subdir or 'Newreno' in subdir or 'Vegas' in subdir:
                if 'Newreno_1Mb' in subdir:
                    # add that directory to directory path
                    path_directories.append(os.path.join(subdir))
                    # get only the output trace files
                    if '.tr' in file:
                        tracefiles.append(os.path.join(file))
    print(path_directories)
    print(tracefiles)

    # for each in path_directories:
    os.chdir(path_directories[0])
    for each in tracefiles:
        print(each)
        packets = readFile(each)
        calculateThroughput(packets)

main()
